from flask import Flask, render_template, request, jsonify
from conva_ai import AsyncConvaAI

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('Netflix_Assistant_UI.html')

@app.route('/get_movie_recommendations', methods=['POST'])
async def get_movie_recommendations():
    client = AsyncConvaAI(
        assistant_id="aba2f1d5b4e34cc797a277817fdd0dd1",
        assistant_version="15.0.1",
        api_key="b7b30b6337a34b1682ae079e3357e643"
    )

    data = request.json
    query = data.get('query', '')

    # Get the response from Conva.AI
    ai_response = await client.invoke_capability(query)

    # After getting the ai_response
    print(dir(ai_response))  # This will print all attributes and methods of the ai_response object
    print(ai_response)  # This will print the object itself, might give you an idea of its structure

    # Convert the ConvaAIResponse object to a dictionary
    response_dict = {
        "request_id": ai_response.request_id,
        "input_query": ai_response.input_query,
        "message": ai_response.message,
        "reason": ai_response.reason,
        "response_language": ai_response.response_language,
        "is_final": ai_response.is_final,
        "parameters": ai_response.parameters or {},  # This is already a dictionary
        "related_queries": ai_response.related_queries or [],
        "conversation_history": ai_response.conversation_history or '',
        "tool_name": ai_response.tool_name,
        "is_parameter_complete": ai_response.is_parameter_complete
    }

    return jsonify(response_dict)

if __name__ == '__main__':
    app.run(debug=True)
